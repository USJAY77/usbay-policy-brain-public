# Static dependency closure

This supplemental handoff was generated from Git objects at the bound snapshot. No application or test module was imported or executed.

## Coverage

- Required audit, hash-chain, immutable-ledger, exporter, gateway authorization consumer, decision store, compute router, export-authority, scanner, exact-host, and validation-launcher files.
- Recursive repository-local Python imports and parent package initializers discovered through AST parsing.
- Pytest configuration, conftest, repository test helpers, and statically identifiable non-sensitive source/config references.
- Export-authorization implementation and tests introduced by commit 5cb13c28bc19cd2438e488774bb04d154e99dfde.

## Explicit absences

See metadata/absent.json. Absence is from the required snapshot and is not substituted from current HEAD.

## Exclusions and isolated substitutes

See metadata/excluded.json. Private keys, trust registries, public-key authority inputs, signed release/attestation records, runtime state, evidence records, customer data, caches, virtual environments, and installed packages are not included. Isolated tests must use tmp_path-backed synthetic registries, deterministic synthetic tenant/request identifiers, generated test-only keys, and mocked network/TSA/Redis/subprocess/runtime-attestation boundaries. Production defaults must remain fail closed.

## External dependencies

External Python dependencies are named by requirements.txt, requirements-ci.txt, and pyproject.toml but are not vendored. System tools, Redis, TSA/network services, deployment environment, PORT, and runtime provenance are not included.

## Remaining static limitations

Dynamic __import__ call sites were found in test code. Their known target modules are present in the closure, but arbitrary runtime-selected modules/files, environment-selected paths, subprocess binaries, and network services cannot be proven complete by static analysis. The archive therefore does not claim universal dependency completeness.
